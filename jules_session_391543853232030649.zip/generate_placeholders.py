import os

def create_placeholder_svg(filepath, color, text):
    svg_content = f"""<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg">
  <rect width="200" height="200" fill="{color}" rx="20"/>
  <text x="100" y="100" font-family="Arial" font-size="20" fill="white" text-anchor="middle" dominant-baseline="middle">{text}</text>
</svg>"""
    with open(filepath, 'w') as f:
        f.write(svg_content)

# Define paths
base_path = "frontend/public/assets/images"
gifts_path = os.path.join(base_path, "gifts")
cases_path = os.path.join(base_path, "cases")

os.makedirs(gifts_path, exist_ok=True)
os.makedirs(cases_path, exist_ok=True)

# Common Gifts from screenshots
gifts = [
    ("cash_bag.svg", "#4CAF50", "Cash Bag"),
    ("dollars.svg", "#8BC34A", "Dollars"),
    ("gold_bar.svg", "#FFC107", "Gold Bar"),
    ("pepe.svg", "#388E3C", "Pepe"),
    ("gold_pepe.svg", "#FF9800", "Gold Pepe"),
    ("btc.svg", "#FF5722", "Bitcoin"),
    ("rolex.svg", "#795548", "Rolex"),
    ("lamborghini.svg", "#212121", "Lamborghini")
]

# Cases from screenshots
cases = [
    ("money.svg", "#43A047", "Money Case"),
    ("pepe.svg", "#2E7D32", "Pepe Case"),
    ("crypto.svg", "#F4511E", "Crypto Case"),
    ("luxury.svg", "#212121", "Luxury Case")
]

for filename, color, label in gifts:
    create_placeholder_svg(os.path.join(gifts_path, filename), color, label)

for filename, color, label in cases:
    create_placeholder_svg(os.path.join(cases_path, filename), color, label)

print("Placeholder assets created.")
