const ru = {
  store: "Магазин",
  inventory: "Инвентарь",
  battle: "Битва",
  roulette: "Рулетка",
  profile: "Профиль",
  case_store: "Магазин кейсов",
  daily_bonus: "Ежедневный бонус",
  claim: "Забрать",
  find_match: "Найти матч",
  searching: "Поиск оппонента...",
  balance: "Ваш баланс",
  top_up: "Пополнить",
  collect_gift: "Забрать подарок",
  rarity_common: "Обычный",
  rarity_rare: "Редкий",
  rarity_epic: "Эпический",
  rarity_legendary: "Легендарный"
};

export default ru;
