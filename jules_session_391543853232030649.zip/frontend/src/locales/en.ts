const en = {
  store: "Store",
  inventory: "Inventory",
  battle: "Battle",
  roulette: "Roulette",
  profile: "Profile",
  case_store: "Gifts Case Store",
  daily_bonus: "Daily Bonus",
  claim: "Claim",
  find_match: "Find Match",
  searching: "Searching for Opponent...",
  balance: "Your Balance",
  top_up: "Top Up",
  collect_gift: "Collect Gift",
  rarity_common: "Common",
  rarity_rare: "Rare",
  rarity_epic: "Epic",
  rarity_legendary: "Legendary"
};

export default en;
