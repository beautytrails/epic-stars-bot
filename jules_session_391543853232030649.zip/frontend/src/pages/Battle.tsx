import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, User, Loader2 } from 'lucide-react';

const Battle: React.FC = () => {
  const [searching, setSearching] = useState(false);
  const [match, setMatch] = useState<any>(null);

  const startSearch = () => {
    setSearching(true);
    // Simulate finding a match after 3 seconds
    setTimeout(() => {
      setSearching(false);
      setMatch({
        opponent: { username: 'LuckyBot', avatar: null },
        bet: 10
      });
    }, 3000);
  };

  return (
    <div className="space-y-6 flex flex-col items-center justify-center min-h-[70vh]">
      {!searching && !match && (
        <div className="text-center space-y-6">
          <div className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto border-2 border-primary animate-pulse">
            <Swords size={48} className="text-primary" />
          </div>
          <div className="space-y-2">
            <h2 className="text-3xl font-bold">Battle Arena</h2>
            <p className="text-gray-400">Challenge other players and win their gifts!</p>
          </div>
          <button 
            onClick={startSearch}
            className="w-64 bg-primary py-4 rounded-2xl font-bold text-xl shadow-lg shadow-primary/30 hover:scale-105 active:scale-95 transition-all"
          >
            Find Match (10 💎)
          </button>
        </div>
      )}

      {searching && (
        <div className="text-center space-y-8">
          <div className="relative">
            <div className="w-32 h-32 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <User size={40} className="text-primary" />
            </div>
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold">Searching for Opponent...</h2>
            <p className="text-gray-400">Matching you with a worthy challenger</p>
          </div>
          <button 
            onClick={() => setSearching(false)}
            className="text-gray-500 font-bold hover:text-white"
          >
            Cancel
          </button>
        </div>
      )}

      {match && (
        <div className="w-full space-y-8">
           <div className="flex justify-between items-center px-4">
              <div className="flex flex-col items-center space-y-2">
                <div className="w-20 h-20 bg-gray-800 rounded-2xl flex items-center justify-center border-2 border-primary">
                  <User size={40} />
                </div>
                <span className="font-bold">You</span>
              </div>
              
              <div className="text-primary font-black text-4xl italic">VS</div>

              <div className="flex flex-col items-center space-y-2">
                <div className="w-20 h-20 bg-gray-800 rounded-2xl flex items-center justify-center border-2 border-red-500">
                   <img src="https://api.dicebear.com/7.x/bottts/svg?seed=LuckyBot" alt="bot" className="w-16 h-16" />
                </div>
                <span className="font-bold">{match.opponent.username}</span>
              </div>
           </div>

           <div className="bg-dark-card rounded-3xl p-6 border border-gray-800 text-center space-y-4">
              <h3 className="text-xl font-bold">The Duel</h3>
              <div className="flex justify-center space-x-8">
                 <div className="text-4xl font-black text-primary">?</div>
                 <div className="text-4xl font-black text-red-500">?</div>
              </div>
              <p className="text-gray-400">Rolling the dice...</p>
              <div className="w-full bg-gray-800 h-2 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 4 }}
                  className="h-full bg-primary"
                />
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default Battle;
