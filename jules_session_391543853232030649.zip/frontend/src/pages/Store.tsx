import React, { useState } from 'react';
import CaseCard from '../components/ui/CaseCard';
import CaseOpeningModal from '../components/ui/CaseOpeningModal';

const Store: React.FC = () => {
  const [selectedCase, setSelectedCase] = useState<any>(null);

  const cases = [
    { id: 1, name: 'Money', price: 8, imageUrl: '/assets/images/cases/money.svg' },
    { id: 2, name: 'Pepe', price: 10, imageUrl: '/assets/images/cases/pepe.svg' },
    { id: 3, name: 'Crypto', price: 15, imageUrl: '/assets/images/cases/crypto.svg' },
    { id: 4, name: 'Luxury', price: 50, imageUrl: '/assets/images/cases/luxury.svg' },
    { id: 5, name: 'Tech', price: 30, imageUrl: '/assets/images/cases/luxury.svg' }, # Reuse luxury for tech placeholder
    { id: 6, name: 'Legendary', price: 100, imageUrl: '/assets/images/cases/luxury.svg' },
  ];

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-2xl font-bold mb-4 italic">Gifts Case Store</h2>
        <div className="grid grid-cols-2 gap-4">
          {cases.map((c) => (
            <CaseCard 
              key={c.id}
              name={c.name}
              price={c.price}
              imageUrl={c.imageUrl}
              onClick={() => setSelectedCase(c)}
            />
          ))}
        </div>
      </section>
      
      <section className="bg-dark-card rounded-3xl p-6 border border-gray-800 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-2">
            <div className="bg-primary/20 text-primary text-[10px] font-bold px-2 py-0.5 rounded-full">ACTIVE</div>
        </div>
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="font-bold text-xl italic">Daily Bonus</h3>
            <p className="text-gray-500 text-xs">Collect free diamonds every day</p>
          </div>
          <span className="text-primary font-bold text-lg">22:14:05</span>
        </div>
        <button className="w-full bg-primary py-4 rounded-2xl font-bold hover:bg-primary-dark transition-all shadow-lg shadow-primary/20 active:scale-95">
          Claim Bonus
        </button>
      </section>

      <CaseOpeningModal 
        isOpen={!!selectedCase} 
        onClose={() => setSelectedCase(null)} 
        caseName={selectedCase?.name || ''} 
      />
    </div>
  );
};

export default Store;
