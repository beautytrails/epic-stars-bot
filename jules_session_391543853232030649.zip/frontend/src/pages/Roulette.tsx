import React, { useState } from 'react';
import { motion } from 'framer-motion';

const Roulette: React.FC = () => {
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);

  const spin = () => {
    if (spinning) return;
    setSpinning(true);
    const newRotation = rotation + 1800 + Math.random() * 360; // At least 5 full spins
    setRotation(newRotation);
    
    setTimeout(() => {
      setSpinning(false);
    }, 4000);
  };

  return (
    <div className="space-y-8 flex flex-col items-center py-10">
      <h2 className="text-3xl font-black italic text-center">DAILY ROULETTE</h2>
      
      <div className="relative w-72 h-72">
        {/* Pointer */}
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 bg-primary rounded-full z-20 flex items-center justify-center border-4 border-dark">
           <div className="w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[12px] border-t-white mt-4" />
        </div>

        {/* Wheel */}
        <motion.div 
          animate={{ rotate: rotation }}
          transition={{ duration: 4, ease: "circOut" }}
          className="w-full h-full rounded-full border-8 border-dark-card shadow-[0_0_50px_rgba(139,92,246,0.2)] relative overflow-hidden"
          style={{ background: 'conic-gradient(#1f1f1f 0deg 45deg, #2a2a2a 45deg 90deg, #1f1f1f 90deg 135deg, #2a2a2a 135deg 180deg, #1f1f1f 180deg 225deg, #2a2a2a 225deg 270deg, #1f1f1f 270deg 315deg, #2a2a2a 315deg 360deg)' }}
        >
           {[0, 45, 90, 135, 180, 225, 270, 315].map((deg, i) => (
             <div 
              key={i}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none"
              style={{ transform: `translate(-50%, -50%) rotate(${deg + 22.5}deg)` }}
             >
                <div className="pt-8 text-center">
                   <div className="text-sm font-bold">{[5, 10, 50, 'Gift', 5, 20, 100, 'Rare'][i]}</div>
                   <div className="text-[10px] text-primary">💎</div>
                </div>
             </div>
           ))}
        </motion.div>
      </div>

      <button 
        onClick={spin}
        disabled={spinning}
        className={`w-64 py-4 rounded-2xl font-bold text-xl shadow-lg transition-all ${spinning ? 'bg-gray-700' : 'bg-primary shadow-primary/30 hover:scale-105 active:scale-95'}`}
      >
        {spinning ? 'SPINNING...' : 'SPIN (FREE)'}
      </button>

      <p className="text-gray-500 text-sm">Next free spin in 23:59:59</p>
    </div>
  );
};

export default Roulette;
