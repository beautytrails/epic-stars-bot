import React from 'react';
import { motion } from 'framer-motion';

const Inventory: React.FC = () => {
  const items = [
    { id: 1, name: 'Gold Bar', rarity: 'Legendary', imageUrl: '/assets/images/gifts/gold_bar.svg', value: 500 },
    { id: 2, name: 'Pepe Statue', rarity: 'Epic', imageUrl: '/assets/images/gifts/gold_pepe.svg', value: 150 },
    { id: 3, name: 'Bitcoin', rarity: 'Rare', imageUrl: '/assets/images/gifts/btc.svg', value: 80 },
    { id: 4, name: 'Cash Stack', rarity: 'Common', imageUrl: '/assets/images/gifts/cash_bag.svg', value: 20 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">My Inventory</h2>
        <div className="text-gray-400 text-sm">{items.length} items</div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {items.map((item) => (
          <motion.div 
            key={item.id}
            whileTap={{ scale: 0.95 }}
            className="bg-dark-card rounded-2xl p-2 flex flex-col items-center border border-gray-800"
          >
            <div className={`w-full aspect-square rounded-xl mb-2 flex items-center justify-center relative overflow-hidden
              ${item.rarity === 'Legendary' ? 'bg-accent/10 border-accent/20' : 
                item.rarity === 'Epic' ? 'bg-primary/10 border-primary/20' : 'bg-gray-800/50'} border`}>
              <img src={item.imageUrl} alt={item.name} className="w-16 h-16 object-contain z-10" />
            </div>
            <span className="text-[10px] text-gray-400 truncate w-full text-center">{item.name}</span>
            <div className="flex items-center space-x-1 mt-1">
               <span className="text-xs font-bold">{item.value}</span>
               <div className="w-2 h-2 bg-accent rounded-full"></div>
            </div>
          </motion.div>
        ))}
      </div>

      {items.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-gray-500">
          <p>Your inventory is empty</p>
          <button className="mt-4 text-primary font-bold">Go to Store</button>
        </div>
      )}
    </div>
  );
};

export default Inventory;
