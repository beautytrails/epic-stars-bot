import React from 'react';
import { Wallet, Settings, Shield, ChevronRight, CreditCard, Coins } from 'lucide-react';

const Profile: React.FC = () => {
  const stats = [
    { label: 'Total Games', value: '142' },
    { label: 'Wins', value: '86' },
    { label: 'Profit', value: '+1,240 💎' },
  ];

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-dark-card rounded-3xl p-6 border border-gray-800 flex items-center space-x-4">
        <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-3xl font-bold border-4 border-dark-lighter">
          J
        </div>
        <div>
          <h2 className="text-2xl font-bold">Jules Engineer</h2>
          <p className="text-gray-500">ID: 5829104</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="bg-dark-lighter rounded-2xl p-3 text-center border border-gray-800">
            <div className="text-xs text-gray-500 mb-1">{s.label}</div>
            <div className="font-bold text-sm">{s.value}</div>
          </div>
        ))}
      </div>

      {/* Balance & Top-up */}
      <div className="bg-primary/10 rounded-3xl p-6 border border-primary/20">
        <div className="flex justify-between items-center mb-6">
          <div>
            <div className="text-sm text-primary/80 mb-1">Your Balance</div>
            <div className="text-3xl font-black flex items-center">
              1,240 <span className="ml-2">💎</span>
            </div>
          </div>
          <button className="bg-primary p-3 rounded-2xl hover:scale-105 transition-transform">
             <Wallet size={24} />
          </button>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-dark-card rounded-2xl py-4 flex flex-col items-center border border-gray-800 hover:border-primary transition-colors">
            <Coins className="text-primary mb-2" size={24} />
            <span className="font-bold">Telegram Stars</span>
          </button>
          <button className="bg-dark-card rounded-2xl py-4 flex flex-col items-center border border-gray-800 hover:border-primary transition-colors">
            <CreditCard className="text-primary mb-2" size={24} />
            <span className="font-bold">CryptoPay</span>
          </button>
        </div>
      </div>

      {/* Menu Options */}
      <div className="space-y-2">
        <div className="bg-dark-lighter rounded-2xl p-4 flex justify-between items-center border border-gray-800 cursor-pointer hover:bg-gray-800/30 transition-colors">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-800 rounded-xl flex items-center justify-center">
               <Shield size={20} className="text-gray-400" />
            </div>
            <span className="font-bold">Security Settings</span>
          </div>
          <ChevronRight size={20} className="text-gray-600" />
        </div>

        <div className="bg-dark-lighter rounded-2xl p-4 flex justify-between items-center border border-gray-800 cursor-pointer hover:bg-gray-800/30 transition-colors">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-800 rounded-xl flex items-center justify-center">
               <Settings size={20} className="text-gray-400" />
            </div>
            <span className="font-bold">App Language (RU)</span>
          </div>
          <ChevronRight size={20} className="text-gray-600" />
        </div>
      </div>
    </div>
  );
};

export default Profile;
