import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import Store from './pages/Store';
import Inventory from './pages/Inventory';
import Battle from './pages/Battle';
import Profile from './pages/Profile';
import Roulette from './pages/Roulette';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Store />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/pvp" element={<Battle />} />
          <Route path="/roulette" element={<Roulette />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
