import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_URL,
});

// Add Telegram initData to headers if available
api.interceptors.request.use((config) => {
  const initData = window.Telegram?.WebApp?.initData;
  if (initData) {
    config.headers['X-Telegram-Init-Data'] = initData;
  }
  return config;
});

export const appService = {
  getMe: () => api.get('/me'),
  getCases: () => api.get('/cases'),
  openCase: (caseId: number) => api.post(`/cases/${caseId}/open`),
  getInventory: () => api.get('/inventory'),
};

export default api;
