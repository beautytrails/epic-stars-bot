import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, ShoppingBag, User, Award, History, RotateCw } from 'lucide-react';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="flex flex-col min-h-screen bg-dark text-white font-sans overflow-x-hidden">
      {/* Header / Top Bar */}
      <header className="flex justify-between items-center p-4 bg-dark-lighter sticky top-0 z-50 shadow-md">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center font-bold">E</div>
          <span className="font-bold text-lg">Epic Stars</span>
        </div>
        <div className="flex items-center bg-dark-card rounded-full px-3 py-1 space-x-2 border border-gray-800">
          <span className="text-accent font-bold">1,240</span>
          <div className="w-4 h-4 bg-accent rounded-full"></div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow pb-24 p-4">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-dark-lighter border-t border-gray-800 px-6 py-3 flex justify-between items-center z-50">
        <NavLink to="/" className={({ isActive }) => `flex flex-col items-center space-y-1 ${isActive ? 'text-primary' : 'text-gray-500'}`}>
          <Home size={24} />
          <span className="text-xs">Store</span>
        </NavLink>
        <NavLink to="/inventory" className={({ isActive }) => `flex flex-col items-center space-y-1 ${isActive ? 'text-primary' : 'text-gray-500'}`}>
          <ShoppingBag size={24} />
          <span className="text-xs">Inventory</span>
        </NavLink>
        <NavLink to="/pvp" className={({ isActive }) => `flex flex-col items-center space-y-1 ${isActive ? 'text-primary' : 'text-gray-500'}`}>
          <Award size={24} />
          <span className="text-xs">Battle</span>
        </NavLink>
        <NavLink to="/roulette" className={({ isActive }) => `flex flex-col items-center space-y-1 ${isActive ? 'text-primary' : 'text-gray-500'}`}>
          <RotateCw size={24} />
          <span className="text-xs">Roulette</span>
        </NavLink>
        <NavLink to="/profile" className={({ isActive }) => `flex flex-col items-center space-y-1 ${isActive ? 'text-primary' : 'text-gray-500'}`}>
          <User size={24} />
          <span className="text-xs">Profile</span>
        </NavLink>
      </nav>
    </div>
  );
};

export default Layout;
