import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface OpeningModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseName: string;
}

const CaseOpeningModal: React.FC<OpeningModalProps> = ({ isOpen, onClose, caseName }) => {
  const [spinning, setSpinning] = useState(true);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    if (isOpen) {
      setSpinning(true);
      setResult(null);
      
      // Simulate spin
      setTimeout(() => {
        setSpinning(false);
        setResult({
          name: 'Golden Rolex',
          rarity: 'Legendary',
          image: 'https://api.dicebear.com/7.x/shapes/svg?seed=watch'
        });
      }, 3000);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-black/90"
      />
      
      <motion.div 
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-dark-card w-full max-w-sm rounded-3xl p-8 border border-gray-800 relative z-10 text-center space-y-6 overflow-hidden"
      >
        <h2 className="text-2xl font-bold italic text-primary">{caseName.toUpperCase()} CASE</h2>
        
        <div className="relative h-48 flex items-center justify-center">
          {spinning ? (
            <div className="flex space-x-2 animate-pulse">
               {[1,2,3,4,5].map(i => (
                 <div key={i} className="w-16 h-16 bg-gray-800 rounded-xl border border-gray-700 shrink-0" />
               ))}
               <div className="absolute top-0 bottom-0 w-1 bg-primary left-1/2 -translate-x-1/2 z-20 shadow-[0_0_15px_rgba(139,92,246,0.5)]" />
            </div>
          ) : (
            <motion.div 
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="space-y-4"
            >
              <div className="w-32 h-32 bg-primary/20 rounded-3xl mx-auto flex items-center justify-center border-2 border-primary shadow-[0_0_30px_rgba(139,92,246,0.3)]">
                <img src={result.image} alt={result.name} className="w-24 h-24" />
              </div>
              <div>
                <div className="text-primary font-bold text-sm tracking-widest">{result.rarity.toUpperCase()}</div>
                <div className="text-2xl font-black">{result.name}</div>
              </div>
            </motion.div>
          )}
        </div>

        {!spinning && (
          <button 
            onClick={onClose}
            className="w-full bg-primary py-4 rounded-2xl font-bold text-lg hover:bg-primary-dark transition-colors"
          >
            Collect Gift
          </button>
        )}
      </motion.div>
    </div>
  );
};

export default CaseOpeningModal;
