import React from 'react';
import { motion } from 'framer-motion';

interface CaseCardProps {
  name: string;
  price: number;
  imageUrl: string;
  onClick: () => void;
}

const CaseCard: React.FC<CaseCardProps> = ({ name, price, imageUrl, onClick }) => {
  return (
    <motion.div 
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className="bg-dark-card rounded-3xl p-4 flex flex-col items-center space-y-3 cursor-pointer border border-transparent hover:border-primary transition-colors"
    >
      <div className="w-32 h-32 relative flex items-center justify-center">
         {/* Placeholder for case image with glow */}
         <div className="absolute inset-0 bg-primary/20 blur-2xl rounded-full"></div>
         <img src={imageUrl} alt={name} className="w-28 h-28 object-contain relative z-10" />
      </div>
      <div className="text-center">
        <h3 className="font-bold text-lg">{name}</h3>
        <div className="flex items-center justify-center bg-primary/20 rounded-full px-3 py-1 mt-1">
          <span className="text-primary font-bold mr-1">{price}</span>
          <div className="w-3 h-3 bg-primary rounded-full"></div>
        </div>
      </div>
    </motion.div>
  );
};

export default CaseCard;
