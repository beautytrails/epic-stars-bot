import asyncio
from app.db.session import AsyncSessionLocal
from app.models.models import Gift, Case

async def seed():
    async with AsyncSessionLocal() as db:
        # 1. Create Gifts
        gifts = [
            Gift(name="Cash Bag", rarity="common", value=10, image_url="/assets/images/gifts/cash_bag.png"),
            Gift(name="Stack of Dollars", rarity="rare", value=50, image_url="/assets/images/gifts/dollars.png"),
            Gift(name="Gold Bar", rarity="legendary", value=500, image_url="/assets/images/gifts/gold_bar.png"),
            Gift(name="Pepe Frog", rarity="common", value=15, image_url="/assets/images/gifts/pepe.png"),
            Gift(name="Golden Pepe", rarity="epic", value=200, image_url="/assets/images/gifts/gold_pepe.png"),
            Gift(name="Bitcoin", rarity="rare", value=100, image_url="/assets/images/gifts/btc.png"),
        ]
        db.add_all(gifts)
        await db.commit()
        
        # 2. Create Cases
        case1 = Case(
            name="Money", 
            price=8, 
            image_url="/assets/images/cases/money.png",
            items_config=[
                {"gift_id": 1, "weight": 70},
                {"gift_id": 2, "weight": 25},
                {"gift_id": 3, "weight": 5}
            ]
        )
        case2 = Case(
            name="Pepe", 
            price=10, 
            image_url="/assets/images/cases/pepe.png",
            items_config=[
                {"gift_id": 4, "weight": 80},
                {"gift_id": 5, "weight": 20}
            ]
        )
        db.add_all([case1, case2])
        await db.commit()

if __name__ == "__main__":
    asyncio.run(seed())
