from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from typing import List, Dict
import json
import asyncio
from app.services.pvp_service import pvp_manager, Player
from app.services.roulette_service import roulette_manager

router = APIRouter()

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[int, WebSocket] = {}

    async def connect(self, user_id: int, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[user_id] = websocket

    def disconnect(self, user_id: int):
        if user_id in self.active_connections:
            del self.active_connections[user_id]

    async def send_personal_message(self, message: dict, user_id: int):
        if user_id in self.active_connections:
            await self.active_connections[user_id].send_json(message)

manager = ConnectionManager()

@router.websocket("/ws/pvp/{user_id}")
async def pvp_websocket(websocket: WebSocket, user_id: int):
    # In a real app, validate token here
    await manager.connect(user_id, websocket)
    player = Player(user_id=user_id, username=f"User{user_id}", avatar_url=None)
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            if message["action"] == "join_queue":
                await pvp_manager.join_queue(player)
                await manager.send_personal_message({"status": "in_queue"}, user_id)
                
                # Check for match or simulate bot after 5 seconds
                await asyncio.sleep(5)
                match = await pvp_manager.find_match()
                if not match:
                    match = await pvp_manager.add_bot_to_match(player)
                
                await manager.send_personal_message({
                    "status": "match_started",
                    "match_id": match.match_id,
                    "players": [
                        {"user_id": p.user_id, "username": p.username} for p in match.players
                    ]
                }, user_id)
                
            elif message["action"] == "leave_queue":
                await pvp_manager.leave_queue(user_id)
                await manager.send_personal_message({"status": "idle"}, user_id)

    except WebSocketDisconnect:
        manager.disconnect(user_id)
        await pvp_manager.leave_queue(user_id)
