from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from typing import List
from app.db.session import get_db
from app.models.models import User, Case, Gift, InventoryItem
from app.schemas import schemas
from app.core.auth import get_current_user
from app.services import case_service

router = APIRouter()

@router.get("/me", response_model=schemas.User)
async def read_user_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.get("/cases", response_model=List[schemas.Case])
async def read_cases(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Case))
    return result.scalars().all()

@router.post("/cases/{case_id}/open", response_model=schemas.Gift)
async def open_case(
    case_id: int, 
    db: AsyncSession = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    try:
        gift = await case_service.open_case(db, current_user.id, case_id)
        return gift
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/inventory", response_model=List[schemas.InventoryItem])
async def read_inventory(
    db: AsyncSession = Depends(get_db), 
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(InventoryItem)
        .where(InventoryItem.user_id == current_user.id)
    )
    return result.scalars().all()
