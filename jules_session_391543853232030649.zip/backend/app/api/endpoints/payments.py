from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models.models import User, Transaction, TransactionStatus
from app.core.auth import get_current_user
from app.services import payment_service

router = APIRouter()

@router.post("/payments/create/crypto")
async def create_crypto_payment(
    amount: float, 
    asset: str = "USDT",
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    invoice = await payment_service.create_crypto_invoice(amount, asset)
    if not invoice:
        raise HTTPException(status_code=400, detail="Failed to create invoice")
    
    # Save pending transaction
    new_tx = Transaction(
        user_id=current_user.id,
        amount=amount,
        currency=asset,
        status=TransactionStatus.PENDING,
        provider_tx_id=str(invoice["invoice_id"])
    )
    db.add(new_tx)
    await db.commit()
    
    return {"pay_url": invoice["pay_url"], "invoice_id": invoice["invoice_id"]}

@router.post("/payments/create/stars")
async def create_stars_payment(
    amount: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Telegram Stars are handled differently, usually initiated by the bot
    # Here we just return the config for the frontend
    invoice_data = await payment_service.create_stars_invoice(current_user.telegram_id, amount)
    return invoice_data

@router.post("/payments/webhook/cryptobot")
async def cryptobot_webhook(data: dict, db: AsyncSession = Depends(get_db)):
    # Verify signature in real app
    if data["update_type"] == "invoice_paid":
        payload = data["payload"]
        invoice_id = str(payload["invoice_id"])
        
        # Update transaction and user balance
        # ... logic to find tx and user ...
        pass
    return {"ok": True}
