import asyncio
import random
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Player:
    user_id: int
    username: str
    avatar_url: Optional[str]
    is_bot: bool = False

@dataclass
class PVPMatch:
    match_id: str
    players: List[Player]
    bet_amount: float
    status: str # "waiting", "started", "finished"
    winner_id: Optional[int] = None
    rolls: Dict[int, List[int]] = None # user_id -> list of rolls

class PVPManager:
    def __init__(self):
        self.queue: List[Player] = []
        self.active_matches: Dict[str, PVPMatch] = {}
        self.lock = asyncio.Lock()

    async def join_queue(self, player: Player):
        async with self.lock:
            if any(p.user_id == player.user_id for p in self.queue):
                return
            self.queue.append(player)
            
    async def leave_queue(self, user_id: int):
        async with self.lock:
            self.queue = [p for p in self.queue if p.user_id != user_id]

    async def find_match(self) -> Optional[PVPMatch]:
        async with self.lock:
            if len(self.queue) >= 2:
                p1 = self.queue.pop(0)
                p2 = self.queue.pop(0)
                match_id = f"match_{p1.user_id}_{p2.user_id}_{int(datetime.now().timestamp())}"
                match = PVPMatch(
                    match_id=match_id,
                    players=[p1, p2],
                    bet_amount=10.0, # Default for now
                    status="started",
                    rolls={p1.user_id: [], p2.user_id: []}
                )
                self.active_matches[match_id] = match
                return match
        return None

    async def add_bot_to_match(self, player: Player) -> PVPMatch:
        async with self.lock:
            # Remove player from queue if they were there
            self.queue = [p for p in self.queue if p.user_id != player.user_id]
            
            bot = Player(user_id=-1, username="LuckyBot", avatar_url=None, is_bot=True)
            match_id = f"match_{player.user_id}_bot_{int(datetime.now().timestamp())}"
            match = PVPMatch(
                match_id=match_id,
                players=[player, bot],
                bet_amount=10.0,
                status="started",
                rolls={player.user_id: [], bot.user_id: []}
            )
            self.active_matches[match_id] = match
            return match

pvp_manager = PVPManager()
