import random
from typing import List, Dict

class RouletteManager:
    def __init__(self):
        # Configuration for the wheel
        # Items could be currency, items, or multipliers
        self.segments = [
            {"type": "stars", "value": 5, "weight": 50},
            {"type": "stars", "value": 10, "weight": 30},
            {"type": "stars", "value": 50, "weight": 10},
            {"type": "stars", "value": 100, "weight": 5},
            {"type": "item", "rarity": "rare", "weight": 4},
            {"type": "item", "rarity": "epic", "weight": 1},
        ]

    def spin(self) -> dict:
        weights = [s["weight"] for s in self.segments]
        result = random.choices(self.segments, weights=weights, k=1)[0]
        return result

roulette_manager = RouletteManager()
