import random
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.models.models import Case, Gift, InventoryItem, User
from app.schemas.schemas import Gift as GiftSchema

async def open_case(db: AsyncSession, user_id: int, case_id: int):
    # 1. Get case and user
    result = await db.execute(select(Case).where(Case.id == case_id))
    case = result.scalar_one_or_none()
    if not case:
        raise Exception("Case not found")
    
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise Exception("User not found")
    
    # 2. Check balance
    if user.balance < case.price:
        raise Exception("Insufficient balance")
    
    # 3. Deduct balance
    user.balance -= case.price
    
    # 4. Select item
    items_config = case.items_config # List of {"gift_id": id, "weight": weight}
    gift_ids = [item["gift_id"] for item in items_config]
    weights = [item["weight"] for item in items_config]
    
    selected_gift_id = random.choices(gift_ids, weights=weights, k=1)[0]
    
    # 5. Add to inventory
    new_item = InventoryItem(user_id=user.id, gift_id=selected_gift_id)
    db.add(new_item)
    
    # Get gift details for response
    result = await db.execute(select(Gift).where(Gift.id == selected_gift_id))
    gift = result.scalar_one()
    
    await db.commit()
    await db.refresh(new_item)
    
    return gift
