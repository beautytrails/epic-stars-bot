import os
import httpx
from typing import Optional

CRYPTO_PAY_TOKEN = os.getenv("CRYPTO_PAY_TOKEN")
CRYPTO_PAY_API_URL = "https://pay.crypt.bot/api"

async def create_crypto_invoice(amount: float, asset: str = "USDT"):
    if not CRYPTO_PAY_TOKEN:
        return None
        
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{CRYPTO_PAY_API_URL}/createInvoice",
            headers={"Crypto-Pay-API-Token": CRYPTO_PAY_TOKEN},
            json={
                "asset": asset,
                "amount": str(amount),
                "description": "Epic Stars Balance Top-up",
            }
        )
        if response.status_code == 200:
            return response.json()["result"]
    return None

async def create_stars_invoice(user_id: int, amount: int):
    # This would typically use a library like aiogram or raw bot API
    # Since I'm just the backend for the Mini App, I'll return the data needed
    # for the frontend to initiate the payment via the bot if using Stars.
    # Actually, for Stars, the Mini App can't directly 'create' the invoice without the bot.
    # Usually the backend tells the bot to send an invoice or returns a link.
    return {
        "title": "Top-up Balance",
        "description": f"Purchase {amount} Diamonds",
        "payload": f"stars_{user_id}_{amount}",
        "currency": "XTR", # XTR is for Telegram Stars
        "prices": [{"label": "Diamonds", "amount": amount}]
    }
