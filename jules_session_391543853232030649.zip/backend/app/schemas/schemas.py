from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class UserBase(BaseModel):
    telegram_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    language_code: str = "en"

class UserCreate(UserBase):
    pass

class User(UserBase):
    id: int
    balance: float
    is_admin: bool
    created_at: datetime

    class Config:
        from_attributes = True

class GiftBase(BaseModel):
    name: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    rarity: str
    value: float

class Gift(GiftBase):
    id: int

    class Config:
        from_attributes = True

class CaseBase(BaseModel):
    name: str
    description: Optional[str] = None
    image_url: Optional[str] = None
    price: float
    items_config: List[dict] # List of {gift_id: int, weight: float}

class Case(CaseBase):
    id: int

    class Config:
        from_attributes = True

class InventoryItem(BaseModel):
    id: int
    gift: Gift
    acquired_at: datetime

    class Config:
        from_attributes = True

class TransactionBase(BaseModel):
    amount: float
    currency: str

class TransactionCreate(TransactionBase):
    pass

class Transaction(TransactionBase):
    id: int
    status: str
    created_at: datetime

    class Config:
        from_attributes = True
