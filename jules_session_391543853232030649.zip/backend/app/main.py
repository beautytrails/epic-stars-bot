from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from app.core.auth import validate_telegram_data
from app.api.endpoints import app_logic, websockets, payments

app = FastAPI(title="Epic Stars Gift API")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, replace with actual frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(app_logic.router, prefix="/api")
app.include_router(websockets.router)
app.include_router(payments.router, prefix="/api")

@app.get("/")
async def root():
    return {"message": "Welcome to Epic Stars Gift API"}

@app.get("/health")
async def health_check():
    return {"status": "ok"}
