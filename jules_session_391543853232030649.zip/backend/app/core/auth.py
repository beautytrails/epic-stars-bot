import hmac
import hashlib
import json
from urllib.parse import parse_qs, unquote

def validate_init_data(init_data: str, bot_token: str) -> dict | None:
    try:
        parsed_data = parse_qs(init_data)
        if 'hash' not in parsed_data:
            return None
        
        received_hash = parsed_data.pop('hash')[0]
        data_check_string = '\n'.join([f"{k}={v[0]}" for k, v in sorted(parsed_data.items())])
        
        secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
        calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        
        if calculated_hash == received_hash:
            user_data = json.loads(parsed_data.get('user', ['{}'])[0])
            return user_data
        return None
    except Exception:
        return None
