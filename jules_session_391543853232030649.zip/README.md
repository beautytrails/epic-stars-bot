# Epic Stars Gift - Telegram Mini App

A full-stack Telegram Mini App for opening gift cases, battling other players, and managing an inventory of digital gifts.

## Tech Stack

- **Backend:** FastAPI (Python), SQLAlchemy, PostgreSQL, WebSockets.
- **Frontend:** React, Vite, TypeScript, Tailwind CSS, Framer Motion.
- **Payments:** Telegram Stars & CryptoPay (CryptoBot).
- **Localization:** Automatic RU/EN detection.

## Project Structure

```
.
├── backend/            # FastAPI Backend
│   ├── app/
│   │   ├── api/        # API Endpoints
│   │   ├── core/       # Auth & Config
│   │   ├── db/         # DB Session & Base
│   │   ├── models/     # SQLAlchemy Models
│   │   ├── schemas/    # Pydantic Schemas
│   │   └── services/   # Business Logic (PVP, RNG, Payments)
│   └── main.py         # Entry Point
├── frontend/           # React Frontend
│   ├── src/
│   │   ├── components/ # UI & Layout Components
│   │   ├── locales/    # i18n (RU/EN)
│   │   ├── pages/      # Application Pages
│   │   └── services/   # API Clients
│   └── tailwind.config.js
└── screenshots/        # Original UI Reference
```

## Setup & Running

### Backend
1. `cd backend`
2. `python3 -m venv venv`
3. `source venv/bin/activate`
4. `pip install -r requirements.txt`
5. `uvicorn app.main:app --reload`

### Frontend
1. `cd frontend`
2. `npm install`
3. `npm run dev`

## Features

- **Case Store:** Open various cases with different rarities and gifts.
- **Inventory:** View and manage your collected gifts.
- **PVP Battle:** Real-time matching with other players (or bots) to win gifts.
- **Roulette:** Daily free spin for prizes.
- **Profile:** Manage balance and view stats.
- **Localization:** Full support for Russian and English.
